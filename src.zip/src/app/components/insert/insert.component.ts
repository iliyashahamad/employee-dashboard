import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/employee';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent 
{
  constructor(private service:EmployeeService,private router:Router){}
  emp=new Employee();
  save(){
    this.service.saveRrcord(this.emp).subscribe({
      next:data=>this.router.navigate(["/dashboard"])
    })
  }
}
