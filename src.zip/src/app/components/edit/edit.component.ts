import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/employee';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent 
{
  emp:Employee;
  constructor(private route:ActivatedRoute,private service:EmployeeService,private router:Router)
{
  let x=route.snapshot.params["id"];
  this.service.getRecord(x).subscribe({
    next:data=>{this.emp=data;console.log(this.emp);
    }
  })
}
update(){
  this.service.updateRrcord(this.emp).subscribe({
    next:data=>this.router.navigate(["/dashboard"])
  })
}
}

