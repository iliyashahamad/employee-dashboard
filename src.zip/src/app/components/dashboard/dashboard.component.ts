import { NotExpr } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/employee';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit
{
  constructor(private service:EmployeeService){}
  empList:Employee[];
  ngOnInit():void
  {
    this.loadRecord();
  }
  loadRecord(){
    this.service.getList().subscribe({
      next:data=>this.empList=data
    });
  }
  delete(id:number){
    let x=confirm("Are You Sure to Delete?")
    if(x){
    this.service.deleteRecord(id).subscribe({
      next:data=>this.loadRecord()
    })
  }
}
}