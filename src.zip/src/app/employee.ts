export class Employee 
{
    id:number;
    firstname:string;
    lastname:string;
    phone:string;
    email:string;
    department:string;
    salary:number;
}
